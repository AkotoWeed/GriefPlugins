﻿package api;

public class BlockAdd {

	private int x;
	private int y;
	private int z;
	private int type;
	private int byte0;

	public BlockAdd(int x, int y, int z, int type, int byte0) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.type = type;
		this.byte0 = byte0;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getZ() {
		return z;
	}

	public void setZ(int z) {
		this.z = z;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public byte getByte0() {
		return (byte) byte0;
	}

	public void setByte0(int byte0) {
		this.byte0 = byte0;
	}
	
}
