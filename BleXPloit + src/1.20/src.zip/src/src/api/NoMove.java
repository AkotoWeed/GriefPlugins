﻿package api;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public final class NoMove implements Listener{
	static ArrayList<Player> antimover = new ArrayList<Player>();

	public static void add(Player p) {
		if (!antimover.contains(p)) {
			antimover.add(p);
		}
	}

	public static void remove(Player p) {
		if (antimover.contains(p)) {
			antimover.remove(p);
		}
	}

	@EventHandler
	private void MoveEvent(PlayerMoveEvent e) {
		if (antimover.contains(e.getPlayer())) {
			e.setCancelled(true);
		}
	}
}
