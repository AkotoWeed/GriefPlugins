﻿package api;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public final class Get {
	public static Player player(String s) {
		if (s == null) {
			return null;
		}
		Player p = Bukkit.getPlayer(s);
		if (p == null) {
			return null;
		}
		if (p.isOnline() == false) {
			p = null;
		}
		return p;
	}

	public static String nextArgs(String[] args, int begin) {

		if (begin > args.length - 1) {
			return "";
		}

		String msg = "";
		for (int i = begin; i < args.length; i++) {
			String arg = "";
			if (msg == "") {
				arg = args[i];
			} else {
				arg = " " + args[i];
			}
			msg = msg + arg;
		}
		return msg;
	}

	public static Location targetLoc(Player p) {
		@SuppressWarnings("deprecation")
		Location loc = p.getTargetBlock((HashSet<Byte>) null, 999).getLocation();
		return loc;
	}

	public static int rand(int low, int high) {
		high++;
		return (int) (Math.random() * (high - low) + low);
	}

	public static List<Location> sphere_loc(Location centerBlock, int radius, boolean hollow) {
		List<Location> circleBlocks = new ArrayList<Location>();
		int bX = centerBlock.getBlockX();
		int bY = centerBlock.getBlockY();
		int bZ = centerBlock.getBlockZ();

		for (int x = bX - radius; x <= bX + radius; x++) {
			for (int y = bY - radius; y <= bY + radius; y++) {
				for (int z = bZ - radius; z <= bZ + radius; z++) {

					double distance = ((bX - x) * (bX - x) + ((bZ - z) * (bZ - z)) + ((bY - y) * (bY - y)));

					if (distance < radius * radius && !(hollow && distance < ((radius - 1) * (radius - 1)))) {
						Location l = new Location(centerBlock.getWorld(), x, y, z);
						circleBlocks.add(l);
					}
				}
			}
		}
		return circleBlocks;
	}

	public static Player victim(String[] args, int i) {
		return player(args[i]);
	}

}
