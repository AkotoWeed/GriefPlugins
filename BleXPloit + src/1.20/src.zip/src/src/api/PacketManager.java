﻿package api;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import de.blexploit.players.Mittrollers;
import de.blexploit.players.create.GetrolltEntity;
import de.blexploit.players.create.MittrollerEntity;

public class PacketManager {

	private Player receiver;
	private String packetName = "";
	private Class<?>[] parameterTypes;
	private Object[] constructor;

	public PacketManager(String PacketName, Class<?>... parameterTypes) {
		this.packetName = PacketName;
		this.parameterTypes = parameterTypes;
	}

	public void sendTo(Player receiver, Object... constructor) {
		this.receiver = receiver;
		this.constructor = constructor;
		execute();
	}

	public void sendTo(ArrayList<GetrolltEntity> receivers, Object... constructor) {
		for (GetrolltEntity rePlayer : receivers) {
			Player p = rePlayer.getPlayer();
			this.receiver = p;
			this.constructor = constructor;
			execute();
		}
	}

	public void sendTo(MittrollerEntity receiver, Object... constructor) {
		this.receiver = receiver.getPlayer();
		this.constructor = constructor;
		execute();
	}

	private void execute() {
		try {
			if (receiver.isOnline() == false || receiver == null) {
				return;
			}
			Object ob = this.getConnection(receiver);
			Method mSendPacket = null;
			for (Method m : ob.getClass().getMethods()) {
				if (m.getName().equals("sendPacket")) {
					mSendPacket = m;
				}
			}
			if (mSendPacket == null) {
				Mittrollers.sendMessage("§cFehler: §4Packet konnte nicht versendet werden, Version Inkompatibel.");
				return;
			}
			Class<?> c = getNMSClass(packetName);
			Constructor<?>[] pts = c.getConstructors();
			Constructor<?> nct = null;

			for (Constructor<?> cs : pts) {
				if (this.parameterTypes.length == cs.getParameterTypes().length) {
					int container = this.parameterTypes.length;
					for (int i = 0; i < cs.getParameterTypes().length; i++) {
						Class<?> paratype = cs.getParameterTypes()[i];
						Class<?> compare = this.parameterTypes[i];
						if (paratype.equals(compare)) {
							container--;
						}
					}
					if (container == 0) {
						nct = cs;
					}
				}
			}
			if (nct == null) {
				Mittrollers.sendMessage("§cFehler: §4Constructur wurde nicht gefunden.");
				return;
			}
			mSendPacket.invoke(ob, nct.newInstance(this.constructor));

		} catch (Exception e) {
			Mittrollers.sendMessage("§cFehler: §4Packet konnte nicht versendet werden.");
		}

	}

	private Object getConnection(Player player) throws SecurityException, NoSuchMethodException, NoSuchFieldException,
			IllegalArgumentException, IllegalAccessException, InvocationTargetException {

		Method getHandle = player.getClass().getMethod("getHandle");
		Object nmsPlayer = getHandle.invoke(player);
		Field conField = nmsPlayer.getClass().getField("playerConnection");
		Object con = conField.get(nmsPlayer);
		return con;
	}

	public static Object getEntityPlayer(Player player) {
		try {
			Method getHandle = player.getClass().getMethod("getHandle");
			Object nmsPlayer = getHandle.invoke(player);
			return nmsPlayer;
		} catch (Exception e) {
			return null;
		}

	}

	public static Class<?> getNMSClass(String nmsClassString) throws ClassNotFoundException {
		String version = Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3] + ".";
		String name = "net.minecraft.server." + version + nmsClassString;
		Class<?> nmsClass = Class.forName(name);
		return nmsClass;
	}

}
