﻿package api;

import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public final class InteractCheck {
	public static boolean AllowItem(PlayerInteractEvent e) {
		if (e.getPlayer().getItemInHand() == null) {
			return false;
		}
		if (!e.getPlayer().getItemInHand().hasItemMeta()) {
			return false;
		}
		if (e.getPlayer().getItemInHand().getItemMeta().getDisplayName() == null) {
			return false;
		}
		if (e.getAction() == Action.PHYSICAL) {
			return false;
		}
		return true;
	}

	public static boolean rigt_click(PlayerInteractEvent e) {
		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean left_click(PlayerInteractEvent e) {
		if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
			return true;
		} else {
			return false;
		}
	}
}
