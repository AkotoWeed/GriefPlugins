﻿package api;

public enum Fehler {
	
	PLAYER_NOT_FOUND("Dieser Spieler wurde nicht gefunden!"),
	ARGUMENT_EXCEPTION("Falsche Argumente!"),
	NO_PERMISSIONS("Du musst ein Admin sein um diesen Befehl auszuführen!"),
	NUMBER_FORMAT_EXCEPTION("Deine Eingabe muss eine Zahl sein!"),
	ITEM_IN_HAND_NULLPOINT("Es wurde kein Item in deiner Hand gefunden!"),
	UNKNOWN_EXCEPTION("Ein unbekannter Fehler ist bei diesem Vorgang aufgetreten!"),
	UNSUPPORTED_COMMAND("Dieser Befehl konnte nicht ausgeführt werden. Möglicherweise wird er in dieser Version nicht unterstützt."),
	MITROLLER_BLOCK("Dies kannst du nicht bei einem Mittroller machen!");

	private String output;
	private Fehler(String output) {
		this.output = output;
	}
	
	public String getOutput() {
		return this.output;
	}
	
}
