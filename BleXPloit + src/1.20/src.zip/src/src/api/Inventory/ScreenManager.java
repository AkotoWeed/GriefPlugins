﻿
package api.Inventory;

import java.util.concurrent.CopyOnWriteArrayList;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 *
 * Klasse für das Management der Screens
 * @author Flaflo
 *
 */
public final class ScreenManager implements Listener {

	//Manager Instanz
	private static ScreenManager INSTANCE;
	private final JavaPlugin pluginInstance;

	private final CopyOnWriteArrayList<Screen> screens;

	/**
	 * Konstruktor für den ScreenManager
	 * @param pluginInstance Plugininstanz, indem die API benutzt wird
	 */
	public ScreenManager(JavaPlugin pluginInstance) {
		INSTANCE = this;

		this.pluginInstance = pluginInstance;
		this.screens = new CopyOnWriteArrayList<Screen>();

		pluginInstance.getServer().getPluginManager().registerEvents(this, pluginInstance);
	}

	/**
	 * Unregestriert einen Screen beim Manager
	 * @param screen Der zu unregestrierende Screen
	 */
	public void unregister(Screen screen) {
		this.screens.remove(screen);
	}

	/**
	 * Registriert einen Screen beim Manager
	 * @param screen Der zu registrierende Screen
	 */
	public void register(Screen screen) {
		this.screens.add(screen);
	}

	@EventHandler
	public void onInventoryClick(InventoryClickEvent e) {
		for (final Screen scr : this.screens) {
			if (scr.getInventory().equals(e.getInventory()))
				if (scr.getInventory().getContents()[e.getSlot()] != null) //Ist der Slot nicht leer
					e.setCancelled(scr.onClick((Player) e.getWhoClicked(), e.getSlot(), e.getClick(), e.getAction(), e.getCurrentItem())); //Wenn true, breche ab
		}
	}

	/**
	 * Gibt die offenen Screens zurück
	 * @return the screens
	 */
	public CopyOnWriteArrayList<Screen> getScreens() {
		return this.screens;
	}

	/**
	 * Gibt die aktuelle Managerinstanz zurück
	 * @return the instance
	 */
	public static ScreenManager getInstance() {
		return INSTANCE;
	}

	/**
	 * Gibt die Plugininstanz zurück
	 * @return the pluginInstance
	 */
	public JavaPlugin getPluginInstance() {
		return this.pluginInstance;
	}
}
