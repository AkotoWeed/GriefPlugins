﻿package api.Inventory.component;

import org.bukkit.inventory.ItemStack;

/**
 * Komponenten Klasse um einen Button</br>
 * zu visualisieren
 * 
 * @author Flaflo
 *
 */
public class ItemButton {

	private int slot;
	private ItemStack stack;

	/**
	 * Konstruktor des ItemButtons
	 * 
	 * @param slot
	 *            Slot, indem der Button angezeigt wird
	 * @param stack
	 *            Icon des Buttons anhand des Stakcs
	 */
	public ItemButton(int slot, ItemStack stack) {
		this.slot = slot;
		this.stack = stack;
	}

	/**
	 * Gibt den Slot des Buttons zurück
	 * 
	 * @return the slot
	 */
	public int getSlot() {
		return slot;
	}

	/**
	 * Setzt den Slot des Buttons
	 * 
	 * @param slot
	 *            Neuer Slot
	 */
	public void setSlot(int slot) {
		this.slot = slot;
	}

	/**
	 * Gibt das Icon (ItemStack) zurück
	 * 
	 * @return the stack
	 */
	public ItemStack getStack() {
		return stack;
	}

	/**
	 * Setzt das Icon (ItemStack)
	 * 
	 * @param stack
	 *            Neues Icon (ItemStack)
	 */
	public void setStack(ItemStack stack) {
		this.stack = stack;
	}
}
