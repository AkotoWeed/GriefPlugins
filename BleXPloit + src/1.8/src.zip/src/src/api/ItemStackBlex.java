﻿package api;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemStackBlex {

	public static ItemStack create(final Material m, final Integer byt, final String display, final String lorename,
			final int i) {
		final ItemStack item = createItem(m, byt, display, lorename, i);
		de.blexploit.manager.InvProtectManager.tohide.add(item);
		return item;
	}

	public static ItemStack create(final Material m, final Integer byt, final String display, final String lorename,
			final int i, final boolean hide) {
		final ItemStack item = createItem(m, byt, display, lorename, i);
		if (hide) {
			de.blexploit.manager.InvProtectManager.tohide.add(item);
		}
		return item;
	}

	private static ItemStack createItem(final Material m, final Integer byt, final String display,
			final String lorename, final int i) {
		Byte bytn = (byte) 0;
		if (byt != null) {
			try {
				bytn = Byte.parseByte(byt + "");
			} catch (final Exception e) {
				return null;
			}
		}
		final ItemStack Item = new ItemStack(m, i, bytn);
		final ItemMeta ItemMeta = Item.getItemMeta();
		if (display != null) {
			ItemMeta.setDisplayName(display);
		}
		final ArrayList<String> lore = new ArrayList<>();
		if (lorename != null) {
			if (lorename.contains(";")) {
				final String[] lines = lorename.split(";");
				for (int i2 = 0; i2 < lines.length; i2++) {
					if (i2 == 0) {
						lore.add("§6" + lines[i2]);
					} else {
						if (lines[i2].startsWith("%")) {
							lore.add("§6" + lines[i2].replace("%", ""));
						} else {
							lore.add("§2" + lines[i2]);
						}

					}
				}
			} else {
				lore.add("§6" + lorename);
			}
			ItemMeta.setLore(lore);
		}
		Item.setItemMeta(ItemMeta);
		de.blexploit.manager.InvProtectManager.tohide.add(Item);
		return Item;
	}

	public static boolean hasnodelay(final HashMap<Player, Long> hash, final Player p, final double sec) {
		if (!hash.containsKey(p)) {
			return false;
		}
		final Long oldt = hash.get(p);
		final Long nowt = System.currentTimeMillis();
		final Long differ = nowt - oldt;
		final Long userdelay = (long) (sec * 1000);
		if (differ >= userdelay) {
			return true;
		} else {
			return false;
		}
	}

}
