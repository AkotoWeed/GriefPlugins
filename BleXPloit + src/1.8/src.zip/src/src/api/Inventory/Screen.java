﻿package api.Inventory;

import java.util.concurrent.CopyOnWriteArrayList;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import api.Inventory.component.ItemButton;

/**
 * Abstrakte Klasse um einen Screen zu erstellen
 * 
 * @author Flaflo
 *
 */
public abstract class Screen {

	private JavaPlugin pluginInstance;
	
	private Inventory inventory;

	private String title;
	private Player player;

	private boolean closeable, closed;
	private int taskId = -1;
	
	private CopyOnWriteArrayList<ItemButton> buttons;
	
	/**
	 * Konstruktor für die Screenklasse</br>
	 * Hierbei ist das Inventar automatisch schließbar
	 *
 	 * @param pluginInstance Die Instanz des Plugins, in welcher die API benutzt wird
	 * @param title Titel des Inventars
	 * @param player Der Spieler, der das Inventar bekommt
	 * @param height Größe dens Inventars (1 ~ 8)
	 */
	public Screen(JavaPlugin pluginInstance, String title, Player player, int height) {
		this.pluginInstance = pluginInstance;
		
		this.title = title;
		this.player = player;

		this.closeable = true;
		
		this.inventory = pluginInstance.getServer().createInventory(player, height * 9, title);
		
		this.buttons = new CopyOnWriteArrayList<ItemButton>();
		
		this.addComponents();
		this.rebuild();
	}

	/**
	 * Konstruktor für die Screenklasse
	 * 
	 * @param pluginInstance Die Instanz des Plugins, in welcher die API benutzt wird
	 * @param title Titel des Inventars
	 * @param player Der Spieler, der das Inventar bekommt
	 * @param height Größe dens Inventars (1 ~ 8)
	 * @param closeable Ist das Inventar schließbar?
	 */
	public Screen(JavaPlugin pluginInstance, String title, Player player, int height, boolean closeable) {
		this.pluginInstance = pluginInstance;
		
		this.title = title;
		this.player = player;

		this.closeable = closeable;

		this.inventory = pluginInstance.getServer().createInventory(player, height * 9, title);
		
		this.addComponents();
		this.rebuild();
	}

	/**
	 * Methode um im Inventar ein Item hinzuzufügen
	 * @param slot Slot des Buttons
	 * @param stack Stack des Buttons
	 */
	private void addButton(int slot, ItemStack stack) {
		this.inventory.setItem(slot, stack);
	}
	
	/**
	 * Fügt einen Button zum Screen hinzu
	 * @param ib Button der hinzugefügt wird
	 */
	public void addButton(ItemButton ib) {
		this.buttons.add(ib);
	}
	
	/**
	 * Öffnet den Screen beim Spieler
	 */
	public void show() {
		this.player.openInventory(this.inventory);

		this.taskId = new BukkitRunnable() {

			@Override
			public void run() {
				if (!Screen.this.closed) {
					if (!Screen.this.isCloseable())
						if (Screen.this.getPlayer().getOpenInventory().getTitle() != Screen.this.getInventory().getTitle())
							Screen.this.getPlayer().openInventory(Screen.this.getInventory());
				} else
					this.cancel();
				
				Screen.this.rebuild();
			}

		}.runTaskTimer(pluginInstance, 20L, 1L).getTaskId();
		
		ScreenManager.getInstance().register(this);
	}

	/**
	 * Schließt den Screen wieder
	 */
	public void close() {
		this.closed = true;
		this.pluginInstance.getServer().getScheduler().cancelTask(taskId);
		this.player.closeInventory();
		
		ScreenManager.getInstance().unregister(this);
	}

	/**
	 * Wird aufgerufen, wenn das Inventar initialisiert wird
	 */
	public abstract void addComponents();
	/**
	 * Wird aufgerufen wenn der Spieler auf das Inventar klickt</br>
	 * und dessen Slot nicht leer ist.
	 * 
	 * @param player Spieler, der geklickt hat
	 * @param slot Der Slot, auf den geklickt wurde
	 * @param type Typ der Interaktion mit dem Slot
	 * @param action Typ der Aktion beim Slot
	 * @param stack ItemStack der betroffen ist
	 * 
	 * @return <b>cancelled</b> Wird das Event abgebrochen?
	 */
	public abstract boolean onClick(Player player, int slot, ClickType type, InventoryAction action, ItemStack stack);

	/**
	 * Erstellt jede Komponent neu auf das Inventar
	 */
	public void rebuild() {
		this.inventory.clear();

		for (ItemButton ib : buttons)
			this.addButton(ib.getSlot(), ib.getStack());
	}
	
	/**
	 * Gibt den Titel des Screens zurück
	 * @return the title
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * Gibt den Spieler, der den Screen besitzt zurück
	 * @return
	 */
	public Player getPlayer() {
		return this.player;
	}

	/**
	 * Gibt das Inventar zurück
	 * @return the inventory
	 */
	public Inventory getInventory() {
		return this.inventory;
	}

	/**
	 * Gibt zuürck ob der Screen schließbar ist
	 * @return closeable
	 */
	public boolean isCloseable() {
		return closeable;
	}

	/**
	 * Setzt den Screen un/schließbar
	 * @param closeable ist es schließbar?
	 */
	public void setCloseable(boolean closeable) {
		this.closeable = closeable;
	}
	
	/**
	 * Gibt zurück ob der Screen schließbar ist
	 * @return closed
	 */
	public boolean isClosed() {
		return this.closed;
	}

	/**
	 * Gibt eine Liste der Komponenten zurück
	 * @return the buttons
	 */
	public CopyOnWriteArrayList<ItemButton> getButtons() {
		return this.buttons;
	}
}
