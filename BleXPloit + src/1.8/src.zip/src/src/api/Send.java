﻿package api;

import java.lang.reflect.Method;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class Send {

	public static void PlayerSound(Location loc, String sound, float lautstärke, float pitch, Player p) {
		try {
			Sound s = null;
			for (Sound onS : Sound.values()) {
				if (onS.name().equalsIgnoreCase(sound)) {
					s = onS;
				}
			}
			if (s == null) {
				String newsound = "";
				if (sound.contains("_")) {
					String[] sargs = sound.split("_");
					if (sargs.length > 0) {

						for (int i = 1; i < sargs.length; i++) {
							if (i == sargs.length - 1) {
								newsound += sargs[i];
							} else {
								newsound += sargs[i] + "_";
							}
						}
					}
				}
				for (Sound onS : Sound.values()) {
					if (onS.name().equalsIgnoreCase(newsound)) {
						s = onS;
					}
				}
				if (s == null) {
					for (Sound onS : Sound.values()) {
						if (onS.name().toUpperCase().contains(newsound.toUpperCase())) {
							s = onS;
						} else if (newsound.toUpperCase().contains(onS.name().toUpperCase())) {
							s = onS;
						}
					}
				}
			}

			if (s != null) {
				p.playSound(loc, s, lautstärke, pitch);
			}
		} catch (Exception e) {
		}

	}

	public static void PlayerSound(String sound, Location loc, float lautstärke, float pitch, Player p) {
		PlayerSound(loc, sound, lautstärke, pitch, p);
	}

	public static void OnlinePlayersSound(String sound, Location loc, float lautstärke, float pitch) {
		for (Player p : Bukkit.getOnlinePlayers()) {
			PlayerSound(loc, sound, lautstärke, pitch, p);
		}
	}

	public static void OnlinePlayersMsg(String msg) {
		for (Player p : Bukkit.getOnlinePlayers()) {
			p.sendMessage(msg);
		}
	}

	public static boolean Titel(Player empfänger, String args0, String args1) {
		try {
			boolean compatible = false;
			Method titelMethode = null;
			for (Method m : Player.class.getMethods()) {
				if (m.getName().equals("sendTitle")) {
					compatible = true;
					titelMethode = m;
				}
			}
			if (compatible == true) {
				titelMethode.invoke(empfänger, args0, args1);
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	@SuppressWarnings("deprecation")
	public static void BlockChange(Player p, Location paramLocation, Material paramMaterial, byte paramByte) {
		p.sendBlockChange(paramLocation, paramByte, paramByte);
	}

}
