﻿package api;

import java.util.ArrayList;

import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public final class Godmode implements Listener {

	static ArrayList<Entity> godEntitys = new ArrayList<>();

	public static void add(Entity e) {
		godEntitys.add(e);
	}

	public static void remove(Entity e) {
		if (godEntitys.contains(e)) {
			godEntitys.remove(e);
		}
	}

	@EventHandler
	public static void noDmg(EntityDamageEvent e) {
		if (godEntitys.contains(e.getEntity())) {
			e.setCancelled(true);
		}
	}

}
