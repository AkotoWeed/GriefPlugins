﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;

namespace Qlutch_Console
{
	// Token: 0x02000004 RID: 4
	public partial class Console : Form
	{
		// Token: 0x06000022 RID: 34 RVA: 0x00003444 File Offset: 0x00001644
		public Console()
		{
			bool flag = !File.Exists("Newtonsoft.Json.dll");
			if (flag)
			{
				MessageBox.Show("Missing dependencies");
			}
			else
			{
				this.InitializeComponent();
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x000034B0 File Offset: 0x000016B0
		private static string GetIPAddress()
		{
			WebClient webClient = new WebClient();
			return webClient.DownloadString("https://api.ipify.org/");
		}

		// Token: 0x06000024 RID: 36 RVA: 0x000034D8 File Offset: 0x000016D8
		public void Form1_Load(object sender, EventArgs e)
		{
			try
			{
				WebRequest webRequest = WebRequest.Create("https://api.minecraftforceop.com/?ip=" + Console.GetIPAddress());
				WebResponse response = webRequest.GetResponse();
				StreamReader streamReader = new StreamReader(response.GetResponseStream());
				string value = streamReader.ReadToEnd();
				object arg = JsonConvert.DeserializeObject<object>(value);
				if (Console.<>o__2.<>p__2 == null)
				{
					Console.<>o__2.<>p__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(Console), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Func<CallSite, object, bool> target = Console.<>o__2.<>p__2.Target;
				CallSite <>p__ = Console.<>o__2.<>p__2;
				if (Console.<>o__2.<>p__1 == null)
				{
					Console.<>o__2.<>p__1 = CallSite<Func<CallSite, Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToBoolean", null, typeof(Console), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Func<CallSite, Type, object, object> target2 = Console.<>o__2.<>p__1.Target;
				CallSite <>p__2 = Console.<>o__2.<>p__1;
				Type typeFromHandle = typeof(Convert);
				if (Console.<>o__2.<>p__0 == null)
				{
					Console.<>o__2.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "hasConsole", typeof(Console), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				bool flag = target(<>p__, target2(<>p__2, typeFromHandle, Console.<>o__2.<>p__0.Target(Console.<>o__2.<>p__0, arg)));
				if (flag)
				{
					base.Show();
				}
				else
				{
					this.playersbackground.Visible = false;
					base.Hide();
					HWID hwid = new HWID();
					hwid.ShowDialog();
					base.Close();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00003688 File Offset: 0x00001888
		private void menubar_mouseDown(object sender, MouseEventArgs e)
		{
			this.drag = true;
			this.start_point = new Point(e.X, e.Y);
		}

		// Token: 0x06000026 RID: 38 RVA: 0x000036AC File Offset: 0x000018AC
		private void menubar_mouseMove(object sender, MouseEventArgs e)
		{
			bool flag = this.drag;
			if (flag)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this.start_point.X, point.Y - this.start_point.Y);
			}
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00003705 File Offset: 0x00001905
		private void menubar_mouseUp(object sender, MouseEventArgs e)
		{
			this.drag = false;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x0000370F File Offset: 0x0000190F
		private void exit_Click(object sender, EventArgs e)
		{
			Environment.Exit(1);
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00003719 File Offset: 0x00001919
		private void minimize_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00003724 File Offset: 0x00001924
		private void minimize_mouseEnter(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00003738 File Offset: 0x00001938
		private void minimize_mouseLeave(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.Silver;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000374C File Offset: 0x0000194C
		private void exit_mouseEnter(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00003760 File Offset: 0x00001960
		private void exit_mouseLeave(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.Silver;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00003774 File Offset: 0x00001974
		public void updateData(string text)
		{
			bool invokeRequired = this.dataBox.InvokeRequired;
			if (invokeRequired)
			{
				Console.SetTextCallback method = new Console.SetTextCallback(this.updateData);
				base.Invoke(method, new object[]
				{
					text
				});
			}
			else
			{
				this.dataBox.AppendText(text + "\n");
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x000037D0 File Offset: 0x000019D0
		private void connecttext_Click(object sender, EventArgs e)
		{
			bool flag = this.clickable;
			if (flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(this.serveraddressTXT.Text);
				if (flag2)
				{
					MessageBox.Show("Please enter an IP address");
				}
				else
				{
					this.connect.BackColor = Color.WhiteSmoke;
					this.connect.BorderStyle = BorderStyle.FixedSingle;
					this.connecttext.ForeColor = Color.Gray;
					this.clickable = false;
					string text = this.serveraddressTXT.Text;
					string value = text.Split(new char[]
					{
						':'
					}).Last<string>();
					bool flag3 = this.client != null;
					if (flag3)
					{
						this.client.Disconnect();
					}
					this.client = new SocketServer(text.Split(new char[]
					{
						':'
					}).First<string>(), Convert.ToInt32(value));
					this.dataBox.Clear();
					this.client.Connection += this.Client_Connection;
					this.client.MessageReceive += this.Client_MessageReceive;
					this.client.Disconnection += this.Client_Disconnection;
					Application.ApplicationExit += this.Application_ApplicationExit;
				}
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003916 File Offset: 0x00001B16
		private void Application_ApplicationExit(object sender, EventArgs e)
		{
			this.client.Disconnect();
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003928 File Offset: 0x00001B28
		private void Client_Disconnection()
		{
			try
			{
				base.Invoke(new Action(delegate()
				{
					this.dataBox.AppendText("Disconnected.\n");
					base.Focus();
				}));
			}
			catch
			{
			}
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003964 File Offset: 0x00001B64
		private void Client_Connection(bool isConnected)
		{
			base.Invoke(new Action(delegate()
			{
				bool flag = !isConnected;
				if (flag)
				{
					MessageBox.Show("Error connecting to the server");
				}
				else
				{
					this.dataBox.AppendText("Connected.\n");
				}
			}));
		}

		// Token: 0x06000033 RID: 51 RVA: 0x0000399C File Offset: 0x00001B9C
		private void Client_MessageReceive(string message)
		{
			base.Invoke(new Action(delegate()
			{
				this.dataBox.AppendText(message + "\n");
			}));
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000039D4 File Offset: 0x00001BD4
		private void serveraddressTXT_textChanged(object sender, EventArgs e)
		{
			this.clickable = true;
			this.connect.BorderStyle = BorderStyle.None;
			this.connecttext.ForeColor = Color.White;
			this.connect.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00003A20 File Offset: 0x00001C20
		private void connect_mouseEnter(object sender, EventArgs e)
		{
			bool flag = this.clickable;
			if (flag)
			{
				this.connect.BackColor = Color.FromArgb(243, 119, 31);
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00003A54 File Offset: 0x00001C54
		private void connect_mouseLeave(object sender, EventArgs e)
		{
			bool flag = this.clickable;
			if (flag)
			{
				this.connect.BackColor = Color.FromArgb(250, 105, 0);
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00003A88 File Offset: 0x00001C88
		private void connecttext_mouseEnter(object sender, EventArgs e)
		{
			bool flag = this.clickable;
			if (flag)
			{
				this.connect.BackColor = Color.FromArgb(243, 119, 31);
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003ABC File Offset: 0x00001CBC
		private void connecttext_mouseLeave(object sender, EventArgs e)
		{
			bool flag = this.clickable;
			if (flag)
			{
				this.connect.BackColor = Color.FromArgb(250, 105, 0);
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003AF0 File Offset: 0x00001CF0
		private void showGeneral(bool b)
		{
			this.serveraddressTXT.Visible = b;
			this.background.Visible = b;
			this.connect.Visible = b;
			this.clear.Visible = b;
			this.address.Visible = b;
			this.save.Visible = b;
			this.dataBox.Visible = b;
			this.serverlog.Visible = b;
			this.sendcommand.Visible = b;
			this.send.Visible = b;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003B80 File Offset: 0x00001D80
		private void players_Click(object sender, EventArgs e)
		{
			this.playersbackground.Visible = true;
			this.showGeneral(false);
			this.playerspanel.BackColor = Color.FromArgb(250, 105, 0);
			this.pluginspanel.BackColor = Color.FromArgb(75, 39, 13);
			this.generalpanel.BackColor = Color.FromArgb(75, 39, 13);
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00003BEC File Offset: 0x00001DEC
		private void general_Click(object sender, EventArgs e)
		{
			this.playersbackground.Visible = false;
			this.showGeneral(true);
			this.playerspanel.BackColor = Color.FromArgb(75, 39, 13);
			this.pluginspanel.BackColor = Color.FromArgb(75, 39, 13);
			this.generalpanel.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00003C58 File Offset: 0x00001E58
		private void plugins_Click(object sender, EventArgs e)
		{
			this.showGeneral(false);
			this.playersbackground.Visible = false;
			this.playerspanel.BackColor = Color.FromArgb(75, 39, 13);
			this.generalpanel.BackColor = Color.FromArgb(75, 39, 13);
			this.pluginspanel.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00003CC4 File Offset: 0x00001EC4
		private void players_mouseEnter(object sender, EventArgs e)
		{
			bool flag = this.playerspanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.playerspanel.BackColor = Color.FromArgb(134, 61, 9);
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00003D10 File Offset: 0x00001F10
		private void players_mouseLeave(object sender, EventArgs e)
		{
			bool flag = this.playerspanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.playerspanel.BackColor = Color.FromArgb(75, 39, 13);
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00003D58 File Offset: 0x00001F58
		private void sendcommand_textChanged(object sender, EventArgs e)
		{
			this.send.BorderStyle = BorderStyle.None;
			this.sendtext.ForeColor = Color.White;
			this.send.BackColor = Color.FromArgb(250, 105, 0);
			this.sendclickable = true;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00003DA4 File Offset: 0x00001FA4
		private void sendtext_Click(object sender, EventArgs e)
		{
			bool flag = this.sendclickable;
			if (flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(this.sendcommand.Text);
				if (flag2)
				{
					MessageBox.Show("You cannot send an empty command");
				}
				this.client.Send("EXE " + this.sendcommand.Text);
				this.dataBox.AppendText("> " + this.sendcommand.Text + "\n");
				this.sendclickable = false;
				this.sendcommand.Text = string.Empty;
				this.send.BorderStyle = BorderStyle.FixedSingle;
				this.sendtext.ForeColor = Color.Gray;
				this.send.BackColor = Color.WhiteSmoke;
			}
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00003E70 File Offset: 0x00002070
		private void clear_Click(object sender, EventArgs e)
		{
			this.dataBox.Text = string.Empty;
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00003E84 File Offset: 0x00002084
		private void save_Click(object sender, EventArgs e)
		{
			this.saveFileDialog1.DefaultExt = "txt";
			this.saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
			this.saveFileDialog1.FilterIndex = 2;
			bool flag = this.saveFileDialog1.ShowDialog() == DialogResult.OK;
			if (flag)
			{
				StreamWriter streamWriter = new StreamWriter(this.saveFileDialog1.FileName);
				streamWriter.Write(this.dataBox.Text);
				streamWriter.Close();
			}
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00003EFF File Offset: 0x000020FF
		private void save_mouseEnter(object sender, EventArgs e)
		{
			this.save.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00003F1C File Offset: 0x0000211C
		private void save_mouseLeave(object sender, EventArgs e)
		{
			this.save.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00003F38 File Offset: 0x00002138
		private void clear_mouseEnter(object sender, EventArgs e)
		{
			this.clear.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00003F55 File Offset: 0x00002155
		private void clear_mouseLeave(object sender, EventArgs e)
		{
			this.clear.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00003F74 File Offset: 0x00002174
		private void general_mouseEnter(object sender, EventArgs e)
		{
			bool flag = this.generalpanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.generalpanel.BackColor = Color.FromArgb(134, 61, 9);
			}
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003FC0 File Offset: 0x000021C0
		private void general_mouseLeave(object sender, EventArgs e)
		{
			bool flag = this.generalpanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.generalpanel.BackColor = Color.FromArgb(75, 39, 13);
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00004008 File Offset: 0x00002208
		private void plugins_mouseEnter(object sender, EventArgs e)
		{
			bool flag = this.pluginspanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.pluginspanel.BackColor = Color.FromArgb(134, 61, 9);
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00004054 File Offset: 0x00002254
		private void plugins_mouseLeave(object sender, EventArgs e)
		{
			bool flag = this.pluginspanel.BackColor != Color.FromArgb(250, 105, 0);
			if (flag)
			{
				this.pluginspanel.BackColor = Color.FromArgb(75, 39, 13);
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x0000409C File Offset: 0x0000229C
		private void freezeall_Click(object sender, EventArgs e)
		{
			bool flag = this.allfrozen;
			if (flag)
			{
				MessageBox.Show("Everyone is already frozen.");
			}
			else
			{
				this.client.Send("FREEZEALL NOW");
				this.allfrozen = true;
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x000040E0 File Offset: 0x000022E0
		private void unfreezeall_Click(object sender, EventArgs e)
		{
			bool flag = this.allfrozen;
			if (flag)
			{
				this.client.Send("UNFREEZEALL NOW");
				this.allfrozen = false;
			}
			else
			{
				this.client.Send("UNFREEZEALLPLAYERS NOW");
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004127 File Offset: 0x00002327
		private void opall_Click(object sender, EventArgs e)
		{
			this.client.Send("OPALL NOW");
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000413B File Offset: 0x0000233B
		private void deopall_Click(object sender, EventArgs e)
		{
			this.client.Send("DEOPALL NOW");
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000414F File Offset: 0x0000234F
		private void banall_Click(object sender, EventArgs e)
		{
			this.client.Send("BANALL NOW");
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004163 File Offset: 0x00002363
		private void freezeall_mouseEnter(object sender, EventArgs e)
		{
			this.freezeall.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004180 File Offset: 0x00002380
		private void freezeall_mouseLeave(object sender, EventArgs e)
		{
			this.freezeall.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0000419C File Offset: 0x0000239C
		private void unfreezeall_mouseEnter(object sender, EventArgs e)
		{
			this.unfreezeall.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000041B9 File Offset: 0x000023B9
		private void unfreezeall_mouseLeave(object sender, EventArgs e)
		{
			this.unfreezeall.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000041D5 File Offset: 0x000023D5
		private void opall_mouseEnter(object sender, EventArgs e)
		{
			this.opall.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000041F2 File Offset: 0x000023F2
		private void opall_mouseLeave(object sender, EventArgs e)
		{
			this.opall.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0000420E File Offset: 0x0000240E
		private void deopall_mouseEnter(object sender, EventArgs e)
		{
			this.deopall.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000422B File Offset: 0x0000242B
		private void deopall_mouseLeave(object sender, EventArgs e)
		{
			this.deopall.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004247 File Offset: 0x00002447
		private void banall_mouseEnter(object sender, EventArgs e)
		{
			this.banall.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00004264 File Offset: 0x00002464
		private void banall_mouseLeave(object sender, EventArgs e)
		{
			this.banall.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00004280 File Offset: 0x00002480
		private void op_Click(object sender, EventArgs e)
		{
			this.client.Send("EXE OP " + this.username.Text);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000042A4 File Offset: 0x000024A4
		private void op_mouseLeave(object sender, EventArgs e)
		{
			this.op.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000042C0 File Offset: 0x000024C0
		private void op_mouseEnter(object sender, EventArgs e)
		{
			this.op.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x04000017 RID: 23
		private bool drag = false;

		// Token: 0x04000018 RID: 24
		private Point start_point = new Point(0, 0);

		// Token: 0x04000019 RID: 25
		private bool clickable = false;

		// Token: 0x0400001A RID: 26
		private SocketServer client;

		// Token: 0x0400001B RID: 27
		private bool sendclickable = false;

		// Token: 0x0400001C RID: 28
		private bool allfrozen = false;

		// Token: 0x02000009 RID: 9
		// (Invoke) Token: 0x06000075 RID: 117
		public delegate void SetTextCallback(string text);
	}
}
