﻿namespace Qlutch_Console
{
	// Token: 0x02000004 RID: 4
	public partial class Console : global::System.Windows.Forms.Form
	{
		// Token: 0x0600005D RID: 93 RVA: 0x000042E0 File Offset: 0x000024E0
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00004318 File Offset: 0x00002518
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Qlutch_Console.Console));
			this.menubar = new global::System.Windows.Forms.Panel();
			this.menubar_text = new global::System.Windows.Forms.Label();
			this.menubar_icon = new global::System.Windows.Forms.PictureBox();
			this.minimize = new global::System.Windows.Forms.Label();
			this.exit = new global::System.Windows.Forms.Label();
			this.serveraddressTXT = new global::System.Windows.Forms.TextBox();
			this.address = new global::System.Windows.Forms.Label();
			this.connect = new global::System.Windows.Forms.Panel();
			this.connecttext = new global::System.Windows.Forms.Label();
			this.dataBox = new global::System.Windows.Forms.RichTextBox();
			this.general = new global::System.Windows.Forms.Label();
			this.generalpanel = new global::System.Windows.Forms.Panel();
			this.playerspanel = new global::System.Windows.Forms.Panel();
			this.players = new global::System.Windows.Forms.Label();
			this.background = new global::System.Windows.Forms.Panel();
			this.save = new global::System.Windows.Forms.Label();
			this.clear = new global::System.Windows.Forms.Label();
			this.serverlog = new global::System.Windows.Forms.Label();
			this.sendcommand = new global::System.Windows.Forms.TextBox();
			this.send = new global::System.Windows.Forms.Panel();
			this.sendtext = new global::System.Windows.Forms.Label();
			this.saveFileDialog1 = new global::System.Windows.Forms.SaveFileDialog();
			this.playersbackground = new global::System.Windows.Forms.Panel();
			this.freezeall = new global::System.Windows.Forms.Label();
			this.unfreezeall = new global::System.Windows.Forms.Label();
			this.opped = new global::System.Windows.Forms.Label();
			this.frozen = new global::System.Windows.Forms.Label();
			this.ipaddress = new global::System.Windows.Forms.Label();
			this.deopall = new global::System.Windows.Forms.Label();
			this.opall = new global::System.Windows.Forms.Label();
			this.banall = new global::System.Windows.Forms.Label();
			this.usernames = new global::System.Windows.Forms.Label();
			this.backgroundWorker1 = new global::System.ComponentModel.BackgroundWorker();
			this.plugins = new global::System.Windows.Forms.Label();
			this.pluginspanel = new global::System.Windows.Forms.Panel();
			this.forceop_txt = new global::System.Windows.Forms.Label();
			this.username = new global::System.Windows.Forms.TextBox();
			this.username_txt = new global::System.Windows.Forms.Label();
			this.op = new global::System.Windows.Forms.Label();
			this.menubar.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).BeginInit();
			this.connect.SuspendLayout();
			this.background.SuspendLayout();
			this.send.SuspendLayout();
			this.playersbackground.SuspendLayout();
			base.SuspendLayout();
			this.menubar.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.menubar.Controls.Add(this.menubar_text);
			this.menubar.Controls.Add(this.menubar_icon);
			this.menubar.Controls.Add(this.minimize);
			this.menubar.Controls.Add(this.exit);
			this.menubar.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar.Location = new global::System.Drawing.Point(-15, -3);
			this.menubar.Name = "menubar";
			this.menubar.Size = new global::System.Drawing.Size(766, 27);
			this.menubar.TabIndex = 0;
			this.menubar.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseDown);
			this.menubar.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseMove);
			this.menubar.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseUp);
			this.menubar_text.AutoSize = true;
			this.menubar_text.Font = new global::System.Drawing.Font("Perpetua Titling MT", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar_text.ForeColor = global::System.Drawing.Color.White;
			this.menubar_text.Location = new global::System.Drawing.Point(49, 8);
			this.menubar_text.Name = "menubar_text";
			this.menubar_text.Size = new global::System.Drawing.Size(117, 13);
			this.menubar_text.TabIndex = 2;
			this.menubar_text.Text = "Qlutch Console";
			this.menubar_icon.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("menubar_icon.Image");
			this.menubar_icon.Location = new global::System.Drawing.Point(20, 4);
			this.menubar_icon.Name = "menubar_icon";
			this.menubar_icon.Size = new global::System.Drawing.Size(23, 23);
			this.menubar_icon.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.menubar_icon.TabIndex = 2;
			this.menubar_icon.TabStop = false;
			this.minimize.AutoSize = true;
			this.minimize.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.minimize.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.minimize.Font = new global::System.Drawing.Font("Modern No. 20", 8.249999f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.minimize.ForeColor = global::System.Drawing.Color.Silver;
			this.minimize.Location = new global::System.Drawing.Point(706, 6);
			this.minimize.Name = "minimize";
			this.minimize.Size = new global::System.Drawing.Size(16, 14);
			this.minimize.TabIndex = 1;
			this.minimize.Text = "_";
			this.minimize.UseMnemonic = false;
			this.minimize.Click += new global::System.EventHandler(this.minimize_Click);
			this.minimize.MouseEnter += new global::System.EventHandler(this.minimize_mouseEnter);
			this.minimize.MouseLeave += new global::System.EventHandler(this.minimize_mouseLeave);
			this.exit.AutoSize = true;
			this.exit.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.exit.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.exit.ForeColor = global::System.Drawing.Color.Silver;
			this.exit.Location = new global::System.Drawing.Point(725, 8);
			this.exit.Name = "exit";
			this.exit.Size = new global::System.Drawing.Size(15, 13);
			this.exit.TabIndex = 0;
			this.exit.Text = "X";
			this.exit.UseMnemonic = false;
			this.exit.Click += new global::System.EventHandler(this.exit_Click);
			this.exit.MouseEnter += new global::System.EventHandler(this.exit_mouseEnter);
			this.exit.MouseLeave += new global::System.EventHandler(this.exit_mouseLeave);
			this.serveraddressTXT.BackColor = global::System.Drawing.Color.White;
			this.serveraddressTXT.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.serveraddressTXT.ForeColor = global::System.Drawing.SystemColors.Desktop;
			this.serveraddressTXT.Location = new global::System.Drawing.Point(138, 31);
			this.serveraddressTXT.Name = "serveraddressTXT";
			this.serveraddressTXT.Size = new global::System.Drawing.Size(455, 20);
			this.serveraddressTXT.TabIndex = 1;
			this.serveraddressTXT.TextChanged += new global::System.EventHandler(this.serveraddressTXT_textChanged);
			this.address.AutoSize = true;
			this.address.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.address.ForeColor = global::System.Drawing.Color.Black;
			this.address.Location = new global::System.Drawing.Point(17, 31);
			this.address.Name = "address";
			this.address.Size = new global::System.Drawing.Size(113, 18);
			this.address.TabIndex = 2;
			this.address.Text = "Server Address:";
			this.connect.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.connect.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.connect.Controls.Add(this.connecttext);
			this.connect.Location = new global::System.Drawing.Point(616, 24);
			this.connect.Name = "connect";
			this.connect.Size = new global::System.Drawing.Size(76, 32);
			this.connect.TabIndex = 3;
			this.connect.MouseEnter += new global::System.EventHandler(this.connect_mouseEnter);
			this.connect.MouseLeave += new global::System.EventHandler(this.connect_mouseLeave);
			this.connecttext.AutoSize = true;
			this.connecttext.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.connecttext.ForeColor = global::System.Drawing.Color.Gray;
			this.connecttext.Location = new global::System.Drawing.Point(-1, -1);
			this.connecttext.Name = "connecttext";
			this.connecttext.Padding = new global::System.Windows.Forms.Padding(12, 10, 12, 10);
			this.connecttext.Size = new global::System.Drawing.Size(78, 33);
			this.connecttext.TabIndex = 0;
			this.connecttext.Text = "Connect";
			this.connecttext.Click += new global::System.EventHandler(this.connecttext_Click);
			this.connecttext.MouseEnter += new global::System.EventHandler(this.connecttext_mouseEnter);
			this.connecttext.MouseLeave += new global::System.EventHandler(this.connecttext_mouseLeave);
			this.dataBox.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.dataBox.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.dataBox.Location = new global::System.Drawing.Point(15, 316);
			this.dataBox.Name = "dataBox";
			this.dataBox.ReadOnly = true;
			this.dataBox.Size = new global::System.Drawing.Size(706, 131);
			this.dataBox.TabIndex = 4;
			this.dataBox.Text = "";
			this.general.AutoSize = true;
			this.general.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.general.ForeColor = global::System.Drawing.Color.Silver;
			this.general.Location = new global::System.Drawing.Point(17, 39);
			this.general.Name = "general";
			this.general.Padding = new global::System.Windows.Forms.Padding(0, 5, 28, 4);
			this.general.Size = new global::System.Drawing.Size(88, 27);
			this.general.TabIndex = 5;
			this.general.Text = "General";
			this.general.Click += new global::System.EventHandler(this.general_Click);
			this.general.MouseEnter += new global::System.EventHandler(this.general_mouseEnter);
			this.general.MouseLeave += new global::System.EventHandler(this.general_mouseLeave);
			this.generalpanel.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.generalpanel.Location = new global::System.Drawing.Point(15, 65);
			this.generalpanel.Name = "generalpanel";
			this.generalpanel.Size = new global::System.Drawing.Size(93, 4);
			this.generalpanel.TabIndex = 6;
			this.playerspanel.BackColor = global::System.Drawing.Color.FromArgb(75, 39, 13);
			this.playerspanel.Location = new global::System.Drawing.Point(108, 65);
			this.playerspanel.Name = "playerspanel";
			this.playerspanel.Size = new global::System.Drawing.Size(93, 4);
			this.playerspanel.TabIndex = 8;
			this.players.AutoSize = true;
			this.players.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.players.ForeColor = global::System.Drawing.Color.Silver;
			this.players.Location = new global::System.Drawing.Point(110, 39);
			this.players.Name = "players";
			this.players.Padding = new global::System.Windows.Forms.Padding(2, 5, 28, 4);
			this.players.Size = new global::System.Drawing.Size(87, 27);
			this.players.TabIndex = 7;
			this.players.Text = "Players";
			this.players.Click += new global::System.EventHandler(this.players_Click);
			this.players.MouseEnter += new global::System.EventHandler(this.players_mouseEnter);
			this.players.MouseLeave += new global::System.EventHandler(this.players_mouseLeave);
			this.background.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.background.Controls.Add(this.op);
			this.background.Controls.Add(this.username_txt);
			this.background.Controls.Add(this.username);
			this.background.Controls.Add(this.forceop_txt);
			this.background.Controls.Add(this.save);
			this.background.Controls.Add(this.clear);
			this.background.Controls.Add(this.address);
			this.background.Controls.Add(this.serveraddressTXT);
			this.background.Controls.Add(this.connect);
			this.background.Controls.Add(this.serverlog);
			this.background.Location = new global::System.Drawing.Point(15, 69);
			this.background.Name = "background";
			this.background.Size = new global::System.Drawing.Size(706, 247);
			this.background.TabIndex = 9;
			this.save.AutoSize = true;
			this.save.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.save.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.save.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.save.ForeColor = global::System.Drawing.Color.White;
			this.save.Location = new global::System.Drawing.Point(231, 214);
			this.save.Name = "save";
			this.save.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.save.Size = new global::System.Drawing.Size(80, 25);
			this.save.TabIndex = 5;
			this.save.Text = "Save";
			this.save.Click += new global::System.EventHandler(this.save_Click);
			this.save.MouseEnter += new global::System.EventHandler(this.save_mouseEnter);
			this.save.MouseLeave += new global::System.EventHandler(this.save_mouseLeave);
			this.clear.AutoSize = true;
			this.clear.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.clear.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.clear.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.clear.ForeColor = global::System.Drawing.Color.White;
			this.clear.Location = new global::System.Drawing.Point(145, 214);
			this.clear.Name = "clear";
			this.clear.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.clear.Size = new global::System.Drawing.Size(80, 25);
			this.clear.TabIndex = 4;
			this.clear.Text = "Clear";
			this.clear.Click += new global::System.EventHandler(this.clear_Click);
			this.clear.MouseEnter += new global::System.EventHandler(this.clear_mouseEnter);
			this.clear.MouseLeave += new global::System.EventHandler(this.clear_mouseLeave);
			this.serverlog.AutoSize = true;
			this.serverlog.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.serverlog.Font = new global::System.Drawing.Font("Trebuchet MS", 15.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.serverlog.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.serverlog.Location = new global::System.Drawing.Point(11, 212);
			this.serverlog.Name = "serverlog";
			this.serverlog.Size = new global::System.Drawing.Size(118, 27);
			this.serverlog.TabIndex = 10;
			this.serverlog.Text = "Server Log";
			this.sendcommand.BackColor = global::System.Drawing.Color.White;
			this.sendcommand.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.sendcommand.ForeColor = global::System.Drawing.SystemColors.Desktop;
			this.sendcommand.Location = new global::System.Drawing.Point(15, 465);
			this.sendcommand.Name = "sendcommand";
			this.sendcommand.Size = new global::System.Drawing.Size(606, 20);
			this.sendcommand.TabIndex = 4;
			this.sendcommand.TextChanged += new global::System.EventHandler(this.sendcommand_textChanged);
			this.send.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.send.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.send.Controls.Add(this.sendtext);
			this.send.Location = new global::System.Drawing.Point(645, 464);
			this.send.Name = "send";
			this.send.Size = new global::System.Drawing.Size(76, 23);
			this.send.TabIndex = 11;
			this.sendtext.AutoSize = true;
			this.sendtext.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.sendtext.ForeColor = global::System.Drawing.Color.Gray;
			this.sendtext.Location = new global::System.Drawing.Point(-2, -1);
			this.sendtext.Name = "sendtext";
			this.sendtext.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.sendtext.Size = new global::System.Drawing.Size(78, 23);
			this.sendtext.TabIndex = 0;
			this.sendtext.Text = "Send";
			this.sendtext.Click += new global::System.EventHandler(this.sendtext_Click);
			this.saveFileDialog1.FileName = "server-log.txt";
			this.playersbackground.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.playersbackground.Controls.Add(this.freezeall);
			this.playersbackground.Controls.Add(this.unfreezeall);
			this.playersbackground.Controls.Add(this.opped);
			this.playersbackground.Controls.Add(this.frozen);
			this.playersbackground.Controls.Add(this.ipaddress);
			this.playersbackground.Controls.Add(this.deopall);
			this.playersbackground.Controls.Add(this.opall);
			this.playersbackground.Controls.Add(this.banall);
			this.playersbackground.Controls.Add(this.usernames);
			this.playersbackground.Location = new global::System.Drawing.Point(15, 69);
			this.playersbackground.Name = "playersbackground";
			this.playersbackground.Size = new global::System.Drawing.Size(706, 418);
			this.playersbackground.TabIndex = 6;
			this.playersbackground.Visible = false;
			this.freezeall.AutoSize = true;
			this.freezeall.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.freezeall.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.freezeall.ForeColor = global::System.Drawing.Color.White;
			this.freezeall.Location = new global::System.Drawing.Point(178, 9);
			this.freezeall.Name = "freezeall";
			this.freezeall.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.freezeall.Size = new global::System.Drawing.Size(105, 23);
			this.freezeall.TabIndex = 13;
			this.freezeall.Text = "Freeze All";
			this.freezeall.Click += new global::System.EventHandler(this.freezeall_Click);
			this.freezeall.MouseEnter += new global::System.EventHandler(this.freezeall_mouseEnter);
			this.freezeall.MouseLeave += new global::System.EventHandler(this.freezeall_mouseLeave);
			this.unfreezeall.AutoSize = true;
			this.unfreezeall.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.unfreezeall.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.unfreezeall.ForeColor = global::System.Drawing.Color.White;
			this.unfreezeall.Location = new global::System.Drawing.Point(289, 9);
			this.unfreezeall.Name = "unfreezeall";
			this.unfreezeall.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.unfreezeall.Size = new global::System.Drawing.Size(118, 23);
			this.unfreezeall.TabIndex = 12;
			this.unfreezeall.Text = "Unfreeze All";
			this.unfreezeall.Click += new global::System.EventHandler(this.unfreezeall_Click);
			this.unfreezeall.MouseEnter += new global::System.EventHandler(this.unfreezeall_mouseEnter);
			this.unfreezeall.MouseLeave += new global::System.EventHandler(this.unfreezeall_mouseLeave);
			this.opped.AutoSize = true;
			this.opped.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.opped.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.opped.Location = new global::System.Drawing.Point(555, 47);
			this.opped.Name = "opped";
			this.opped.Size = new global::System.Drawing.Size(55, 16);
			this.opped.TabIndex = 11;
			this.opped.Text = "Opped";
			this.frozen.AutoSize = true;
			this.frozen.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.frozen.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.frozen.Location = new global::System.Drawing.Point(627, 47);
			this.frozen.Name = "frozen";
			this.frozen.Size = new global::System.Drawing.Size(55, 16);
			this.frozen.TabIndex = 10;
			this.frozen.Text = "Frozen";
			this.ipaddress.AutoSize = true;
			this.ipaddress.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.ipaddress.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.ipaddress.Location = new global::System.Drawing.Point(126, 47);
			this.ipaddress.Name = "ipaddress";
			this.ipaddress.Size = new global::System.Drawing.Size(84, 16);
			this.ipaddress.TabIndex = 9;
			this.ipaddress.Text = "IP Address";
			this.deopall.AutoSize = true;
			this.deopall.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.deopall.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.deopall.ForeColor = global::System.Drawing.Color.White;
			this.deopall.Location = new global::System.Drawing.Point(502, 9);
			this.deopall.Name = "deopall";
			this.deopall.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.deopall.Size = new global::System.Drawing.Size(97, 23);
			this.deopall.TabIndex = 8;
			this.deopall.Text = "Deop All";
			this.deopall.Click += new global::System.EventHandler(this.deopall_Click);
			this.deopall.MouseEnter += new global::System.EventHandler(this.deopall_mouseEnter);
			this.deopall.MouseLeave += new global::System.EventHandler(this.deopall_mouseLeave);
			this.opall.AutoSize = true;
			this.opall.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.opall.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.opall.ForeColor = global::System.Drawing.Color.White;
			this.opall.Location = new global::System.Drawing.Point(413, 9);
			this.opall.Name = "opall";
			this.opall.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.opall.Size = new global::System.Drawing.Size(83, 23);
			this.opall.TabIndex = 7;
			this.opall.Text = "Op All";
			this.opall.Click += new global::System.EventHandler(this.opall_Click);
			this.opall.MouseEnter += new global::System.EventHandler(this.opall_mouseEnter);
			this.opall.MouseLeave += new global::System.EventHandler(this.opall_mouseLeave);
			this.banall.AutoSize = true;
			this.banall.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.banall.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.banall.ForeColor = global::System.Drawing.Color.White;
			this.banall.Location = new global::System.Drawing.Point(605, 9);
			this.banall.Name = "banall";
			this.banall.Padding = new global::System.Windows.Forms.Padding(20, 5, 22, 5);
			this.banall.Size = new global::System.Drawing.Size(89, 23);
			this.banall.TabIndex = 6;
			this.banall.Text = "Ban All";
			this.banall.Click += new global::System.EventHandler(this.banall_Click);
			this.banall.MouseEnter += new global::System.EventHandler(this.banall_mouseEnter);
			this.banall.MouseLeave += new global::System.EventHandler(this.banall_mouseLeave);
			this.usernames.AutoSize = true;
			this.usernames.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.usernames.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.usernames.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.usernames.Location = new global::System.Drawing.Point(9, 38);
			this.usernames.Name = "usernames";
			this.usernames.Padding = new global::System.Windows.Forms.Padding(5, 7, 595, 345);
			this.usernames.Size = new global::System.Drawing.Size(689, 370);
			this.usernames.TabIndex = 0;
			this.usernames.Text = "Usernames";
			this.plugins.AutoSize = true;
			this.plugins.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.plugins.ForeColor = global::System.Drawing.Color.Silver;
			this.plugins.Location = new global::System.Drawing.Point(203, 38);
			this.plugins.Name = "plugins";
			this.plugins.Padding = new global::System.Windows.Forms.Padding(2, 5, 29, 4);
			this.plugins.Size = new global::System.Drawing.Size(87, 27);
			this.plugins.TabIndex = 12;
			this.plugins.Text = "Plugins";
			this.plugins.Click += new global::System.EventHandler(this.plugins_Click);
			this.plugins.MouseEnter += new global::System.EventHandler(this.plugins_mouseEnter);
			this.plugins.MouseLeave += new global::System.EventHandler(this.plugins_mouseLeave);
			this.pluginspanel.BackColor = global::System.Drawing.Color.FromArgb(75, 39, 13);
			this.pluginspanel.Location = new global::System.Drawing.Point(201, 65);
			this.pluginspanel.Name = "pluginspanel";
			this.pluginspanel.Size = new global::System.Drawing.Size(93, 4);
			this.pluginspanel.TabIndex = 9;
			this.forceop_txt.AutoSize = true;
			this.forceop_txt.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.forceop_txt.Font = new global::System.Drawing.Font("Trebuchet MS", 15.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.forceop_txt.ForeColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.forceop_txt.Location = new global::System.Drawing.Point(17, 81);
			this.forceop_txt.Name = "forceop_txt";
			this.forceop_txt.Size = new global::System.Drawing.Size(189, 27);
			this.forceop_txt.TabIndex = 11;
			this.forceop_txt.Text = "Minecraft Forceop";
			this.username.BackColor = global::System.Drawing.Color.White;
			this.username.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.username.ForeColor = global::System.Drawing.SystemColors.Desktop;
			this.username.Location = new global::System.Drawing.Point(22, 138);
			this.username.Name = "username";
			this.username.Size = new global::System.Drawing.Size(114, 20);
			this.username.TabIndex = 12;
			this.username_txt.AutoSize = true;
			this.username_txt.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.username_txt.ForeColor = global::System.Drawing.Color.Black;
			this.username_txt.Location = new global::System.Drawing.Point(22, 119);
			this.username_txt.Name = "username_txt";
			this.username_txt.Size = new global::System.Drawing.Size(71, 16);
			this.username_txt.TabIndex = 13;
			this.username_txt.Text = "Username";
			this.op.AutoSize = true;
			this.op.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.op.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.op.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.op.ForeColor = global::System.Drawing.Color.White;
			this.op.Location = new global::System.Drawing.Point(145, 138);
			this.op.Name = "op";
			this.op.Padding = new global::System.Windows.Forms.Padding(20, 3, 22, 3);
			this.op.Size = new global::System.Drawing.Size(67, 21);
			this.op.TabIndex = 14;
			this.op.Text = "Op";
			this.op.Click += new global::System.EventHandler(this.op_Click);
			this.op.MouseEnter += new global::System.EventHandler(this.op_mouseEnter);
			this.op.MouseLeave += new global::System.EventHandler(this.op_mouseLeave);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.ClientSize = new global::System.Drawing.Size(733, 507);
			base.ControlBox = false;
			base.Controls.Add(this.plugins);
			base.Controls.Add(this.pluginspanel);
			base.Controls.Add(this.send);
			base.Controls.Add(this.background);
			base.Controls.Add(this.sendcommand);
			base.Controls.Add(this.playerspanel);
			base.Controls.Add(this.players);
			base.Controls.Add(this.generalpanel);
			base.Controls.Add(this.general);
			base.Controls.Add(this.menubar);
			base.Controls.Add(this.dataBox);
			base.Controls.Add(this.playersbackground);
			this.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Console";
			this.Text = "Console";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			this.menubar.ResumeLayout(false);
			this.menubar.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).EndInit();
			this.connect.ResumeLayout(false);
			this.connect.PerformLayout();
			this.background.ResumeLayout(false);
			this.background.PerformLayout();
			this.send.ResumeLayout(false);
			this.send.PerformLayout();
			this.playersbackground.ResumeLayout(false);
			this.playersbackground.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400001D RID: 29
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x0400001E RID: 30
		private global::System.Windows.Forms.Panel menubar;

		// Token: 0x0400001F RID: 31
		private global::System.Windows.Forms.Label exit;

		// Token: 0x04000020 RID: 32
		private global::System.Windows.Forms.Label minimize;

		// Token: 0x04000021 RID: 33
		private global::System.Windows.Forms.PictureBox menubar_icon;

		// Token: 0x04000022 RID: 34
		private global::System.Windows.Forms.Label menubar_text;

		// Token: 0x04000023 RID: 35
		private global::System.Windows.Forms.Label address;

		// Token: 0x04000024 RID: 36
		private global::System.Windows.Forms.Panel connect;

		// Token: 0x04000025 RID: 37
		private global::System.Windows.Forms.Label connecttext;

		// Token: 0x04000026 RID: 38
		public global::System.Windows.Forms.TextBox serveraddressTXT;

		// Token: 0x04000027 RID: 39
		private global::System.Windows.Forms.RichTextBox dataBox;

		// Token: 0x04000028 RID: 40
		private global::System.Windows.Forms.Label general;

		// Token: 0x04000029 RID: 41
		private global::System.Windows.Forms.Panel generalpanel;

		// Token: 0x0400002A RID: 42
		private global::System.Windows.Forms.Panel playerspanel;

		// Token: 0x0400002B RID: 43
		private global::System.Windows.Forms.Label players;

		// Token: 0x0400002C RID: 44
		private global::System.Windows.Forms.Panel background;

		// Token: 0x0400002D RID: 45
		private global::System.Windows.Forms.Label serverlog;

		// Token: 0x0400002E RID: 46
		public global::System.Windows.Forms.TextBox sendcommand;

		// Token: 0x0400002F RID: 47
		private global::System.Windows.Forms.Panel send;

		// Token: 0x04000030 RID: 48
		private global::System.Windows.Forms.Label sendtext;

		// Token: 0x04000031 RID: 49
		private global::System.Windows.Forms.Label clear;

		// Token: 0x04000032 RID: 50
		private global::System.Windows.Forms.Label save;

		// Token: 0x04000033 RID: 51
		private global::System.Windows.Forms.SaveFileDialog saveFileDialog1;

		// Token: 0x04000034 RID: 52
		private global::System.Windows.Forms.Panel playersbackground;

		// Token: 0x04000035 RID: 53
		private global::System.ComponentModel.BackgroundWorker backgroundWorker1;

		// Token: 0x04000036 RID: 54
		private global::System.Windows.Forms.Label usernames;

		// Token: 0x04000037 RID: 55
		private global::System.Windows.Forms.Label banall;

		// Token: 0x04000038 RID: 56
		private global::System.Windows.Forms.Label deopall;

		// Token: 0x04000039 RID: 57
		private global::System.Windows.Forms.Label opall;

		// Token: 0x0400003A RID: 58
		private global::System.Windows.Forms.Label ipaddress;

		// Token: 0x0400003B RID: 59
		private global::System.Windows.Forms.Label freezeall;

		// Token: 0x0400003C RID: 60
		private global::System.Windows.Forms.Label unfreezeall;

		// Token: 0x0400003D RID: 61
		private global::System.Windows.Forms.Label opped;

		// Token: 0x0400003E RID: 62
		private global::System.Windows.Forms.Label frozen;

		// Token: 0x0400003F RID: 63
		private global::System.Windows.Forms.Label plugins;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.Panel pluginspanel;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.Label op;

		// Token: 0x04000042 RID: 66
		private global::System.Windows.Forms.Label username_txt;

		// Token: 0x04000043 RID: 67
		public global::System.Windows.Forms.TextBox username;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.Label forceop_txt;
	}
}
