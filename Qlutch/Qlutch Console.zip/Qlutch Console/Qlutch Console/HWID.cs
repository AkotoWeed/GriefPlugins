﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Management;
using System.Windows.Forms;

namespace Qlutch_Console
{
	// Token: 0x02000003 RID: 3
	public partial class HWID : Form
	{
		// Token: 0x0600000E RID: 14 RVA: 0x0000293C File Offset: 0x00000B3C
		public HWID()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002968 File Offset: 0x00000B68
		public string getHWIDSerial()
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM win32_PhysicalMedia");
			foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				bool flag = managementObject["SerialNumber"] != null;
				if (flag)
				{
					return managementObject["SerialNumber"].ToString();
				}
			}
			return string.Empty;
		}

		// Token: 0x06000010 RID: 16 RVA: 0x000029F4 File Offset: 0x00000BF4
		public void Form1_Load(object sender, EventArgs e)
		{
			this.hwidTXT.Text = "Error authenticating";
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002A08 File Offset: 0x00000C08
		private void menubar_mouseDown(object sender, MouseEventArgs e)
		{
			this.drag = true;
			this.start_point = new Point(e.X, e.Y);
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002A2C File Offset: 0x00000C2C
		private void menubar_mouseMove(object sender, MouseEventArgs e)
		{
			bool flag = this.drag;
			if (flag)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this.start_point.X, point.Y - this.start_point.Y);
			}
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002A85 File Offset: 0x00000C85
		private void menubar_mouseUp(object sender, MouseEventArgs e)
		{
			this.drag = false;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002A8F File Offset: 0x00000C8F
		private void exit_Click(object sender, EventArgs e)
		{
			Environment.Exit(1);
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002A99 File Offset: 0x00000C99
		private void minimize_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002AA4 File Offset: 0x00000CA4
		private void minimize_mouseEnter(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002AB8 File Offset: 0x00000CB8
		private void minimize_mouseLeave(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.Silver;
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002ACC File Offset: 0x00000CCC
		private void exit_mouseEnter(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x00002AE0 File Offset: 0x00000CE0
		private void exit_mouseLeave(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.Silver;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002AF4 File Offset: 0x00000CF4
		private void copy_click(object sender, EventArgs e)
		{
			Process.Start("https://minecraftforceop.com/");
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00002B02 File Offset: 0x00000D02
		private void copytext_Click(object sender, EventArgs e)
		{
			Process.Start("https://minecraftforceop.com/");
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002B10 File Offset: 0x00000D10
		private void copy_mouseEnter(object sender, EventArgs e)
		{
			this.copy.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002B2D File Offset: 0x00000D2D
		private void copy_mouseLeave(object sender, EventArgs e)
		{
			this.copy.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002B49 File Offset: 0x00000D49
		private void copytext_mouseEnter(object sender, EventArgs e)
		{
			this.copy.BackColor = Color.FromArgb(243, 119, 31);
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002B66 File Offset: 0x00000D66
		private void copytext_mouseLeave(object sender, EventArgs e)
		{
			this.copy.BackColor = Color.FromArgb(250, 105, 0);
		}

		// Token: 0x0400000C RID: 12
		private bool drag = false;

		// Token: 0x0400000D RID: 13
		private Point start_point = new Point(0, 0);
	}
}
