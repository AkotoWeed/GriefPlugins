﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Qlutch_Console
{
	// Token: 0x02000006 RID: 6
	public class SocketServer
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000061 RID: 97 RVA: 0x00006588 File Offset: 0x00004788
		// (remove) Token: 0x06000062 RID: 98 RVA: 0x000065C0 File Offset: 0x000047C0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event SocketServer.DisconnectionEventHandler Disconnection;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000063 RID: 99 RVA: 0x000065F8 File Offset: 0x000047F8
		// (remove) Token: 0x06000064 RID: 100 RVA: 0x00006630 File Offset: 0x00004830
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event SocketServer.ConnectionEventHandler Connection;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000065 RID: 101 RVA: 0x00006668 File Offset: 0x00004868
		// (remove) Token: 0x06000066 RID: 102 RVA: 0x000066A0 File Offset: 0x000048A0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event SocketServer.MessageReceiveEventHandler MessageReceive;

		// Token: 0x06000067 RID: 103 RVA: 0x000066D8 File Offset: 0x000048D8
		public SocketServer(string ip, int port)
		{
			SocketServer <>4__this = this;
			new Thread(delegate()
			{
				<>4__this.client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				<>4__this.client.BeginConnect(new IPEndPoint(IPAddress.Parse(ip), port), new AsyncCallback(<>4__this.ConnectCallback), <>4__this.client);
			}).Start();
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00006730 File Offset: 0x00004930
		public void Send(string msg)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(msg);
			try
			{
				bool connected = this.client.Connected;
				if (connected)
				{
					this.client.BeginSend(bytes, 0, bytes.Length, SocketFlags.None, new AsyncCallback(this.SendCallback), this.client);
				}
			}
			catch
			{
				SocketServer.DisconnectionEventHandler disconnection = this.Disconnection;
				if (disconnection != null)
				{
					disconnection();
				}
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x000067A8 File Offset: 0x000049A8
		public void Disconnect()
		{
			bool connected = this.client.Connected;
			if (connected)
			{
				this.client.Shutdown(SocketShutdown.Both);
				this.client.Close();
				SocketServer.DisconnectionEventHandler disconnection = this.Disconnection;
				if (disconnection != null)
				{
					disconnection();
				}
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x000067F4 File Offset: 0x000049F4
		private void ConnectCallback(IAsyncResult ar)
		{
			bool connected = this.client.Connected;
			if (connected)
			{
				this.client.EndConnect(ar);
				SocketServer.ConnectionEventHandler connection = this.Connection;
				if (connection != null)
				{
					connection(true);
				}
				this.client.BeginReceive(this.buffer, 0, this.buffer.Length, SocketFlags.None, new AsyncCallback(this.ReceiveCallback), this.client);
			}
			else
			{
				SocketServer.ConnectionEventHandler connection2 = this.Connection;
				if (connection2 != null)
				{
					connection2(false);
				}
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00006878 File Offset: 0x00004A78
		private void ReceiveCallback(IAsyncResult ar)
		{
			try
			{
				int num = this.client.EndReceive(ar);
				bool flag = num > 0;
				if (flag)
				{
					string text = Encoding.UTF8.GetString(this.buffer, 0, num);
					text = text.Split(new char[1])[0];
					bool flag2 = text != "";
					if (flag2)
					{
						SocketServer.MessageReceiveEventHandler messageReceive = this.MessageReceive;
						if (messageReceive != null)
						{
							messageReceive(text);
						}
					}
					this.client.BeginReceive(this.buffer, 0, this.buffer.Length, SocketFlags.None, new AsyncCallback(this.ReceiveCallback), this.client);
				}
				else
				{
					bool flag3 = num == 0;
					if (flag3)
					{
						this.Disconnect();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
				bool connected = this.client.Connected;
				if (connected)
				{
					this.client.BeginReceive(this.buffer, 0, this.buffer.Length, SocketFlags.None, new AsyncCallback(this.ReceiveCallback), this.client);
				}
				else
				{
					SocketServer.DisconnectionEventHandler disconnection = this.Disconnection;
					if (disconnection != null)
					{
						disconnection();
					}
				}
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x000069A0 File Offset: 0x00004BA0
		private void SendCallback(IAsyncResult ar)
		{
			int num = this.client.EndSend(ar);
		}

		// Token: 0x04000048 RID: 72
		private Socket client;

		// Token: 0x04000049 RID: 73
		public byte[] buffer = new byte[2048];

		// Token: 0x0200000D RID: 13
		// (Invoke) Token: 0x0600007D RID: 125
		public delegate void ConnectionEventHandler(bool isConnected);

		// Token: 0x0200000E RID: 14
		// (Invoke) Token: 0x06000081 RID: 129
		public delegate void MessageReceiveEventHandler(string message);

		// Token: 0x0200000F RID: 15
		// (Invoke) Token: 0x06000085 RID: 133
		public delegate void DisconnectionEventHandler();
	}
}
