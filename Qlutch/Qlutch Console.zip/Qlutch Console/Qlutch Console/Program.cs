﻿using System;
using System.Windows.Forms;

namespace Qlutch_Console
{
	// Token: 0x02000005 RID: 5
	internal static class Program
	{
		// Token: 0x06000060 RID: 96 RVA: 0x0000656A File Offset: 0x0000476A
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Console());
		}
	}
}
