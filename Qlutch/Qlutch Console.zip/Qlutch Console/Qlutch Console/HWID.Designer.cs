﻿namespace Qlutch_Console
{
	// Token: 0x02000003 RID: 3
	public partial class HWID : global::System.Windows.Forms.Form
	{
		// Token: 0x06000020 RID: 32 RVA: 0x00002B84 File Offset: 0x00000D84
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002BBC File Offset: 0x00000DBC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Qlutch_Console.HWID));
			this.menubar = new global::System.Windows.Forms.Panel();
			this.menubar_text = new global::System.Windows.Forms.Label();
			this.menubar_icon = new global::System.Windows.Forms.PictureBox();
			this.minimize = new global::System.Windows.Forms.Label();
			this.exit = new global::System.Windows.Forms.Label();
			this.hwidTXT = new global::System.Windows.Forms.Label();
			this.copy = new global::System.Windows.Forms.Panel();
			this.copytext = new global::System.Windows.Forms.Label();
			this.menubar.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).BeginInit();
			this.copy.SuspendLayout();
			base.SuspendLayout();
			this.menubar.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.menubar.Controls.Add(this.menubar_text);
			this.menubar.Controls.Add(this.menubar_icon);
			this.menubar.Controls.Add(this.minimize);
			this.menubar.Controls.Add(this.exit);
			this.menubar.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar.Location = new global::System.Drawing.Point(-15, -3);
			this.menubar.Name = "menubar";
			this.menubar.Size = new global::System.Drawing.Size(414, 27);
			this.menubar.TabIndex = 0;
			this.menubar.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseDown);
			this.menubar.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseMove);
			this.menubar.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseUp);
			this.menubar_text.AutoSize = true;
			this.menubar_text.Font = new global::System.Drawing.Font("Perpetua Titling MT", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar_text.ForeColor = global::System.Drawing.Color.White;
			this.menubar_text.Location = new global::System.Drawing.Point(49, 8);
			this.menubar_text.Name = "menubar_text";
			this.menubar_text.Size = new global::System.Drawing.Size(117, 13);
			this.menubar_text.TabIndex = 2;
			this.menubar_text.Text = "Qlutch Console";
			this.menubar_icon.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("menubar_icon.Image");
			this.menubar_icon.Location = new global::System.Drawing.Point(20, 4);
			this.menubar_icon.Name = "menubar_icon";
			this.menubar_icon.Size = new global::System.Drawing.Size(23, 23);
			this.menubar_icon.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.menubar_icon.TabIndex = 2;
			this.menubar_icon.TabStop = false;
			this.minimize.AutoSize = true;
			this.minimize.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.minimize.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.minimize.Font = new global::System.Drawing.Font("Modern No. 20", 8.249999f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.minimize.ForeColor = global::System.Drawing.Color.Silver;
			this.minimize.Location = new global::System.Drawing.Point(362, 6);
			this.minimize.Name = "minimize";
			this.minimize.Size = new global::System.Drawing.Size(16, 14);
			this.minimize.TabIndex = 1;
			this.minimize.Text = "_";
			this.minimize.UseMnemonic = false;
			this.minimize.Click += new global::System.EventHandler(this.minimize_Click);
			this.minimize.MouseEnter += new global::System.EventHandler(this.minimize_mouseEnter);
			this.minimize.MouseLeave += new global::System.EventHandler(this.minimize_mouseLeave);
			this.exit.AutoSize = true;
			this.exit.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.exit.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.exit.ForeColor = global::System.Drawing.Color.Silver;
			this.exit.Location = new global::System.Drawing.Point(380, 9);
			this.exit.Name = "exit";
			this.exit.Size = new global::System.Drawing.Size(15, 13);
			this.exit.TabIndex = 0;
			this.exit.Text = "X";
			this.exit.UseMnemonic = false;
			this.exit.Click += new global::System.EventHandler(this.exit_Click);
			this.exit.MouseEnter += new global::System.EventHandler(this.exit_mouseEnter);
			this.exit.MouseLeave += new global::System.EventHandler(this.exit_mouseLeave);
			this.hwidTXT.AutoSize = true;
			this.hwidTXT.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.hwidTXT.ForeColor = global::System.Drawing.Color.Silver;
			this.hwidTXT.Location = new global::System.Drawing.Point(99, 47);
			this.hwidTXT.Name = "hwidTXT";
			this.hwidTXT.Size = new global::System.Drawing.Size(176, 24);
			this.hwidTXT.TabIndex = 1;
			this.hwidTXT.Text = "Error Authenticating";
			this.hwidTXT.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.copy.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.copy.Controls.Add(this.copytext);
			this.copy.Location = new global::System.Drawing.Point(145, 187);
			this.copy.Name = "copy";
			this.copy.Size = new global::System.Drawing.Size(76, 32);
			this.copy.TabIndex = 2;
			this.copy.Click += new global::System.EventHandler(this.copy_click);
			this.copy.MouseEnter += new global::System.EventHandler(this.copy_mouseEnter);
			this.copy.MouseLeave += new global::System.EventHandler(this.copy_mouseLeave);
			this.copytext.AutoSize = true;
			this.copytext.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.copytext.ForeColor = global::System.Drawing.Color.White;
			this.copytext.Location = new global::System.Drawing.Point(12, 10);
			this.copytext.Name = "copytext";
			this.copytext.Size = new global::System.Drawing.Size(53, 13);
			this.copytext.TabIndex = 0;
			this.copytext.Text = "Website";
			this.copytext.Click += new global::System.EventHandler(this.copytext_Click);
			this.copytext.MouseEnter += new global::System.EventHandler(this.copytext_mouseEnter);
			this.copytext.MouseLeave += new global::System.EventHandler(this.copytext_mouseLeave);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.ClientSize = new global::System.Drawing.Size(387, 280);
			base.ControlBox = false;
			base.Controls.Add(this.copy);
			base.Controls.Add(this.hwidTXT);
			base.Controls.Add(this.menubar);
			this.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "HWID";
			this.Text = "Console";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			this.menubar.ResumeLayout(false);
			this.menubar.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).EndInit();
			this.copy.ResumeLayout(false);
			this.copy.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400000E RID: 14
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x0400000F RID: 15
		private global::System.Windows.Forms.Panel menubar;

		// Token: 0x04000010 RID: 16
		private global::System.Windows.Forms.Label exit;

		// Token: 0x04000011 RID: 17
		private global::System.Windows.Forms.Label minimize;

		// Token: 0x04000012 RID: 18
		private global::System.Windows.Forms.PictureBox menubar_icon;

		// Token: 0x04000013 RID: 19
		private global::System.Windows.Forms.Label menubar_text;

		// Token: 0x04000014 RID: 20
		private global::System.Windows.Forms.Label hwidTXT;

		// Token: 0x04000015 RID: 21
		private global::System.Windows.Forms.Panel copy;

		// Token: 0x04000016 RID: 22
		private global::System.Windows.Forms.Label copytext;
	}
}
