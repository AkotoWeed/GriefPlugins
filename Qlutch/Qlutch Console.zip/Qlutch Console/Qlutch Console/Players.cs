﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Qlutch_Console
{
	// Token: 0x02000002 RID: 2
	public partial class Players : Form
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public Players()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000002 RID: 2 RVA: 0x0000207C File Offset: 0x0000027C
		public void Form1_Load(object sender, EventArgs e)
		{
			base.Show();
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002086 File Offset: 0x00000286
		private void menubar_mouseDown(object sender, MouseEventArgs e)
		{
			this.drag = true;
			this.start_point = new Point(e.X, e.Y);
		}

		// Token: 0x06000004 RID: 4 RVA: 0x000020A8 File Offset: 0x000002A8
		private void menubar_mouseMove(object sender, MouseEventArgs e)
		{
			bool flag = this.drag;
			if (flag)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this.start_point.X, point.Y - this.start_point.Y);
			}
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002101 File Offset: 0x00000301
		private void menubar_mouseUp(object sender, MouseEventArgs e)
		{
			this.drag = false;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x0000210B File Offset: 0x0000030B
		private void exit_Click(object sender, EventArgs e)
		{
			Environment.Exit(1);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00002115 File Offset: 0x00000315
		private void minimize_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002120 File Offset: 0x00000320
		private void minimize_mouseEnter(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002134 File Offset: 0x00000334
		private void minimize_mouseLeave(object sender, EventArgs e)
		{
			this.minimize.ForeColor = Color.Silver;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002148 File Offset: 0x00000348
		private void exit_mouseEnter(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.AntiqueWhite;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x0000215C File Offset: 0x0000035C
		private void exit_mouseLeave(object sender, EventArgs e)
		{
			this.exit.ForeColor = Color.Silver;
		}

		// Token: 0x04000001 RID: 1
		private bool drag = false;

		// Token: 0x04000002 RID: 2
		private Point start_point = new Point(0, 0);
	}
}
