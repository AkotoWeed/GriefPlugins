﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("Qlutch Console")]
[assembly: AssemblyDescription("Connect to Servers")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Qlutch Inc")]
[assembly: AssemblyProduct("Qlutch Console")]
[assembly: AssemblyCopyright("Qlutch Copyright ©  2020")]
[assembly: AssemblyTrademark("Qlutch, Minecraft ForceOp")]
[assembly: ComVisible(false)]
[assembly: Guid("5c346e54-9f18-49c6-af44-51aa1d695f8c")]
[assembly: AssemblyFileVersion("1.0.0.0")]
