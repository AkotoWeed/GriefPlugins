﻿namespace Qlutch_Console
{
	// Token: 0x02000002 RID: 2
	public partial class Players : global::System.Windows.Forms.Form
	{
		// Token: 0x0600000C RID: 12 RVA: 0x00002170 File Offset: 0x00000370
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000021A8 File Offset: 0x000003A8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Qlutch_Console.Players));
			this.menubar = new global::System.Windows.Forms.Panel();
			this.menubar_text = new global::System.Windows.Forms.Label();
			this.menubar_icon = new global::System.Windows.Forms.PictureBox();
			this.minimize = new global::System.Windows.Forms.Label();
			this.exit = new global::System.Windows.Forms.Label();
			this.general = new global::System.Windows.Forms.Label();
			this.generalpanel = new global::System.Windows.Forms.Panel();
			this.background = new global::System.Windows.Forms.Panel();
			this.menubar.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).BeginInit();
			base.SuspendLayout();
			this.menubar.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.menubar.Controls.Add(this.menubar_text);
			this.menubar.Controls.Add(this.menubar_icon);
			this.menubar.Controls.Add(this.minimize);
			this.menubar.Controls.Add(this.exit);
			this.menubar.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar.Location = new global::System.Drawing.Point(-15, -3);
			this.menubar.Name = "menubar";
			this.menubar.Size = new global::System.Drawing.Size(766, 27);
			this.menubar.TabIndex = 0;
			this.menubar.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseDown);
			this.menubar.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseMove);
			this.menubar.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.menubar_mouseUp);
			this.menubar_text.AutoSize = true;
			this.menubar_text.Font = new global::System.Drawing.Font("Perpetua Titling MT", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.menubar_text.ForeColor = global::System.Drawing.Color.White;
			this.menubar_text.Location = new global::System.Drawing.Point(49, 8);
			this.menubar_text.Name = "menubar_text";
			this.menubar_text.Size = new global::System.Drawing.Size(117, 13);
			this.menubar_text.TabIndex = 2;
			this.menubar_text.Text = "Qlutch Console";
			this.menubar_icon.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("menubar_icon.Image");
			this.menubar_icon.Location = new global::System.Drawing.Point(20, 4);
			this.menubar_icon.Name = "menubar_icon";
			this.menubar_icon.Size = new global::System.Drawing.Size(23, 23);
			this.menubar_icon.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.menubar_icon.TabIndex = 2;
			this.menubar_icon.TabStop = false;
			this.minimize.AutoSize = true;
			this.minimize.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.minimize.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.minimize.Font = new global::System.Drawing.Font("Modern No. 20", 8.249999f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.minimize.ForeColor = global::System.Drawing.Color.Silver;
			this.minimize.Location = new global::System.Drawing.Point(706, 6);
			this.minimize.Name = "minimize";
			this.minimize.Size = new global::System.Drawing.Size(16, 14);
			this.minimize.TabIndex = 1;
			this.minimize.Text = "_";
			this.minimize.UseMnemonic = false;
			this.minimize.Click += new global::System.EventHandler(this.minimize_Click);
			this.minimize.MouseEnter += new global::System.EventHandler(this.minimize_mouseEnter);
			this.minimize.MouseLeave += new global::System.EventHandler(this.minimize_mouseLeave);
			this.exit.AutoSize = true;
			this.exit.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.exit.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.exit.ForeColor = global::System.Drawing.Color.Silver;
			this.exit.Location = new global::System.Drawing.Point(725, 8);
			this.exit.Name = "exit";
			this.exit.Size = new global::System.Drawing.Size(15, 13);
			this.exit.TabIndex = 0;
			this.exit.Text = "X";
			this.exit.UseMnemonic = false;
			this.exit.Click += new global::System.EventHandler(this.exit_Click);
			this.exit.MouseEnter += new global::System.EventHandler(this.exit_mouseEnter);
			this.exit.MouseLeave += new global::System.EventHandler(this.exit_mouseLeave);
			this.general.AutoSize = true;
			this.general.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.general.ForeColor = global::System.Drawing.Color.Silver;
			this.general.Location = new global::System.Drawing.Point(17, 39);
			this.general.Name = "general";
			this.general.Padding = new global::System.Windows.Forms.Padding(0, 5, 28, 4);
			this.general.Size = new global::System.Drawing.Size(88, 27);
			this.general.TabIndex = 5;
			this.general.Text = "General";
			this.generalpanel.BackColor = global::System.Drawing.Color.FromArgb(250, 105, 0);
			this.generalpanel.Location = new global::System.Drawing.Point(15, 65);
			this.generalpanel.Name = "generalpanel";
			this.generalpanel.Size = new global::System.Drawing.Size(93, 4);
			this.generalpanel.TabIndex = 6;
			this.background.BackColor = global::System.Drawing.Color.WhiteSmoke;
			this.background.Location = new global::System.Drawing.Point(15, 69);
			this.background.Name = "background";
			this.background.Size = new global::System.Drawing.Size(706, 378);
			this.background.TabIndex = 9;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.ClientSize = new global::System.Drawing.Size(733, 507);
			base.ControlBox = false;
			base.Controls.Add(this.background);
			base.Controls.Add(this.generalpanel);
			base.Controls.Add(this.general);
			base.Controls.Add(this.menubar);
			this.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.FromArgb(17, 17, 17);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Players";
			this.Text = "Console";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			this.menubar.ResumeLayout(false);
			this.menubar.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.menubar_icon).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000003 RID: 3
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000004 RID: 4
		private global::System.Windows.Forms.Panel menubar;

		// Token: 0x04000005 RID: 5
		private global::System.Windows.Forms.Label exit;

		// Token: 0x04000006 RID: 6
		private global::System.Windows.Forms.Label minimize;

		// Token: 0x04000007 RID: 7
		private global::System.Windows.Forms.PictureBox menubar_icon;

		// Token: 0x04000008 RID: 8
		private global::System.Windows.Forms.Label menubar_text;

		// Token: 0x04000009 RID: 9
		private global::System.Windows.Forms.Label general;

		// Token: 0x0400000A RID: 10
		private global::System.Windows.Forms.Panel generalpanel;

		// Token: 0x0400000B RID: 11
		private global::System.Windows.Forms.Panel background;
	}
}
