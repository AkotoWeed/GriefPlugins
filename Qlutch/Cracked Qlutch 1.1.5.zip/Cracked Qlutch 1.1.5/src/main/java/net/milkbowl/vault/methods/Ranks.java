package net.milkbowl.vault.methods;

public enum Ranks {
        SUSPENDED,
        ADMIN,
        PREMIUM,
        LITE,
        FREE
}
