package net.milkbowl.vault.packets;


import net.milkbowl.vault.Core;

public class QPacket  {

    public void registerPackets() {
        //registerCustomPacket(Core.class, PacketIDs.SPacketNotify, PacketType.Sender.SERVER);
    }


    //private void registerCustomPacket(Class packetClass, int packetId, PacketType.Sender sender) {

    //}




}
