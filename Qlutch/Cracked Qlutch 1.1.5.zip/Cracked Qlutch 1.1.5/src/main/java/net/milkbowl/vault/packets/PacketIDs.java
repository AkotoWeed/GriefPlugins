package net.milkbowl.vault.packets;

public class PacketIDs {

    public static final int SPacketNotify = 74;
}
