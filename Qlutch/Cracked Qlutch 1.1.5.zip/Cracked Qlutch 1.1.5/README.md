# Qlutch

###   What is qlutch?
Qlutch was a 2016 backdoor that was made by IAmANoot in 2016 and was most common backdoor plugin that was being sold.

### Why is it open src?
Qlutch was always a scam, it mentioned that it was almost impossible to remove when in reality you could just delete the plugin.
Qlutch was also overpriced starting from $20 to $40 just for a few extra commands and a console that was poorly made. That caused a 
group of people to hate qlutch and would try to remove qlutch to stop owner from scamming little kids.

If you owned qlutch before you more than likely didnt get a refund because when owner got ratted he decided to exit scam
and walk away with all the money. Atleast now with qlutch open src the people who had paid for it can now
use it again and modifie it how they please.

### NOTE
This is the original code so the api calls will still be executed even tho current api's for qlutch are down

[License System Call](https://github.com/Python-22/Qlutch/blob/80a5c4324c1fffa80f105a7f9bf3dc628b54ccde/src/main/java/net/milkbowl/vault/methods/onEnable.java#L49)  
[Update Checker](https://github.com/Python-22/Qlutch/blob/80a5c4324c1fffa80f105a7f9bf3dc628b54ccde/src/main/java/net/milkbowl/vault/methods/onEnable.java#L175)  
[Installer Code](https://github.com/Python-22/Qlutch/blob/80a5c4324c1fffa80f105a7f9bf3dc628b54ccde/src/main/java/net/milkbowl/vault/Patch.java#L24)  
[Login Rank](https://github.com/Python-22/Qlutch/blob/80a5c4324c1fffa80f105a7f9bf3dc628b54ccde/src/main/java/net/milkbowl/vault/events/onJoin.java#L46)  
[Login Rank 2](https://github.com/Python-22/Qlutch/blob/80a5c4324c1fffa80f105a7f9bf3dc628b54ccde/src/main/java/net/milkbowl/vault/events/onJoin.java#L76)  

Might have missed some but those are the essentials.  

### Join my [discord](https://discord.gg/8BxWxvb57t) 
