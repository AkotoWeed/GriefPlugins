package de.impact.commands.eventhandler;

public interface TickTimer {
    void onTick();
}