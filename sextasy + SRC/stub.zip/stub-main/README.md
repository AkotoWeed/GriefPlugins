# stub

note: if you are going to push this as a release, set developmentBuild in the Ectasy class to false, it is just used to see if Ectasy should print error stack traces and stuff.

## todo
- commands
- auth
- datamanager that stores server data in ectasy database
- passwords for logging in
- rcon
- scripting